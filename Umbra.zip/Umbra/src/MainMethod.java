import javax.swing.ImageIcon;


public class MainMethod {
	public static void main(String[] args) {
		//MapGenerator h = new MapGenerator();
		Window  mainWin = new Window("Umbra");

		

	}
}
